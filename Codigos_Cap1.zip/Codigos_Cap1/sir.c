#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ode.c"
//#include "libreria/aleatorios.h" //falta ver 
#define m 4 // numero de ecuaciones

// b=2.4;g=1;mu = 0.1;  estacionalidad (0.5 + 0.5*cos(2*3.14*t/52))
// Parametros del sistema (globales)
double b,mu,g;
FILE *archivo;
char salida[40];
void sistema(double t, double v[], double dv[]); // funcion "sistema" que da las derivadas a integrar

int main()
{
double v[m],dv[m],t=0,tau,dt;
// b=2.2;//11.24;//2.03;//1.52329;//1.0047281;//tasa de contagio media en humanos
//g= 1.;
//mu=0.1;
    b=520.;//*1.8;
    mu=1./(70.);
    g=52;//24.33;//52.;//
    //b = 15*(mu + g);
    float pop=1;//2000000;//1000.;
v[0]=0.05*pop;//0.7*pop;
v[1]=2.5E-4*pop;//0.05*pop;
v[3]=pop;
v[2]=v[3]-v[0]-v[1];
archivo=fopen("incidencia.txt","w");
    tau=175.;//*60.; // tiempo final
dt=0.0005; // diferencial de tiempo
//b=9.97*v[3]/v[0];
/* salida */
//fprintf(archivo,"%.3f\t%.3f\t%.3f\n",t,v[0]*v[1]*b*(0.5 + 0.5 * cos(2*3.14*t/52))/v[3] ,v[1]);
//para el keeling
    fprintf(archivo,"%.3f\t%f\t%f\n",t,0.,v[1]); //*(0.5 + 0.5 * cos(2*3.14*t))
    
int count=0;
while (t <=tau)
	{
	rk4(v,dv,m,t,dt,v,sistema); // integra el sistema utilizando runge-kutta de orden 4
	t+=dt;
	count++;
	//fprintf(archivo,"%.3f\t%.3f\t%.3f\n",t,(b/v[3])*v[0]*v[1]*(0.5 + 0.5*cos(2*3.14*t/52)),v[1]);
        fprintf(archivo,"%.3f\t%g\t%g\n",t,(b/pop)*v[1]*v[0],v[1]);
    }
fclose(archivo);
//system("echo 'source(archhivor)'|r -persist");

    //system("echo \"source(\'grafico.txt\')\"| r --vanilla");

exit(0);

}

void sistema(double t, double v[], double dv[]) // funcion "sistema" que da las derivadas a integrar
{

//*defino las variables
double S,I,R,N;
S=v[0]; I=v[1]; R=v[2]; N=v[0]+v[1]+v[2];

dv[0]= mu*N - (b/N)*S*I- mu*S ;//*(1 + 1*cos(2.*3.14*t/52)) - mu*S ;//(b/N)*S*I*(0.5 + 0.5*cos(2*3.14*t/52))
dv[1]=(b/N)*S*I- (g+mu)*I;//*(1 + 1*cos(2.*3.14*t/52)) - (g+mu)*I;
dv[2]= g*I - mu*R;
N=dv[0]+dv[1]+dv[3] ;

return;
} 
