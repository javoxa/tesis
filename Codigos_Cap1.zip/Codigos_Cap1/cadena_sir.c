#include <stdio.h>
#include <stdlib.h>
#include <math.h>
//#include "ode.c"
//#include "aleatorios.h"

// para distribucion en el periodo infeccioso pero exponencial mu
//para cambiar la distribucion hacerlo con k_gama
// dejar k_mu =1 SIEMPRE!!!!


	
//double b=0.4,g=1./5,mu=1./50; // Parametros
void cadena_s(double H, double N, double dv[], double V[],int k,double tasa,double dt);
void cadena_i(double H, double dv[], double V[],int k,double tasa_mu,double tasa_gama,double dt);
int main()
{
double b=2.02,g=1.,mu=1./(10.);
FILE *archivo;
char file1[20],file2[20];
archivo=fopen("cadenasirn.dat","w");
FILE *plot1,*plot2;
int i,count=0,j,k_mu=1,k_gama=10; //################### este valor k_mu es el "clase de edad" siempre 1!!!
double S[k_mu+1],dS[k_mu+1],I[k_gama+1],dI[k_gama+1],R,SS=0,N,t=0,t_final,dt,H;
double an,an_1,an_2,max,min;
t_final=1000.; dt=0.01;
double t1,t2,tt,Smedio[1000];
int indice=0,contador=0;
tt=0.5*t_final;
/*Condiciones iniciales*/
//R0=b*((1./g)-pow((k_mu/((g/mu)+k_mu)),k_mu));
S[0]=0.9;//1./( b*((1./g)-pow((k_mu/((g/mu)+k_mu)),k_mu)) );
I[0]=0.1;//(mu/b)*( (b*((1./g)-pow((k_mu/((g/mu)+k_mu)),k_mu))) -1.);//2.5E-4;
R= 1.-S[0]-I[0];
/* salida */
//fprintf(archivo,"%.3f\t%.3f\t%.3f\n",t,S[0],I[0]);
N=1.;
S[1]=S[0];I[1]=I[0];
sprintf(file1,"max%.2f%d.dat",b,k_mu);
sprintf(file2,"min%.2f%d.dat",b,k_mu);
plot1=fopen(file1,"w");
plot2=fopen(file2,"w");
for(i=1;i<=k_mu;i++)
{
	S[i]=S[0];
	//I[i]=I[0];
	dS[i]=0.;
}
for(i=1;i<=k_gama;i++)
{
	//S[i]=S[0];
	I[i]=I[0];
	dI[i]=0.;
}
fprintf(archivo,"%f\t%f\t%f\t%f\n",t,S[0],I[0],R);
while (t <=t_final)
	{
		H=b*S[0]*I[0]/(k_mu*N);
		cadena_s(H,N,dS,S,k_mu,mu,dt);
		cadena_i(H,dI,I,k_gama,mu,g,dt);
		
		/*Sumo todo los valores de indice k*/
		dS[0]=0.;dI[0]=0.;
		for (j=1;j<=k_mu;j++)
		{
			dS[0]=dS[0]+dS[j];
			//dI[0]=dI[0]+dI[j];
		}
		for (j=1;j<=k_gama;j++)
		{
			//dS[0]=dS[0]+dS[j];
			dI[0]=dI[0]+dI[j];
		}
		R=k_mu*N-dS[0]-dI[0];
		/*Calculo los maximos y minimos*/
		an=dS[0];an_1=S[0];an_2=SS;
				if (count>3)
				{
					if ( (an_1 > an_2) & (an_1 > an) )
					{
						max=an_1;
						fprintf(plot1,"%.2f\t %f\n",t,max/(k_mu*N));
					}
					if ( (an_1 < an_2) & (an_1 < an) )
					{
						min=an_1;
						/*este contador es para grabar la serie temporal S*/
						//if (t>tt){contador++;}
						fprintf(plot2,"%.2f\t %f\n",t,min/(k_mu*N));
					}
				}
				//if (contador==1){t1=t;}
				//if (contador==2){t2=t;}
				//if ((1<=contador) & (contador <2)){Smedio[indice]=dS[0]/(k_mu*N);indice++;}
		
		//actualizo los nuevos S e I
		SS=S[0];S[0]=dS[0];
		i=0;
		while(i<=k_mu)
		{
			S[i]=dS[i];
			//I[i]=dI[i];
			i++;
		}
		i=0;
		while(i<=k_gama)
		{
			//S[i]=dS[i];
			I[i]=dI[i];
			i++;
		}
		//if (filtro%1==0)
		{fprintf(archivo,"%f\t%f\t%f\t%f\n",t,I[1]/(k_mu*N),I[0]/(k_mu*N),R/(k_mu*N));}
		
		t+=dt;count++;
    }
    /*if (k_mu>=20)
    {
		S[0]=0.;
		max=t2-t1;
		for(count=0;count<=indice-1;count++)
		{
			S[0]+=(Smedio[count]+Smedio[count+1])*0.5*dt;
		}
		printf("valor medio de S= %f , para un k_mu = %d\n",S[0]/max,k_mu);
    }*/

fclose(archivo);
fclose(plot1);
fclose(plot2);
//system("echo 'plot \"ploting.dat\" u 1:2 w lp, \"ploting.dat\" u 1:3 w lp, \"ploting.dat\" u 1:4 w lp'|gnuplot -persist");



//y vs x
//system("echo ' set title \" Cadena SIR con Dinámica Vital RK2\"; plot  \"cadenasirn.dat\" u 1:3 w l t\"Infectados\",\"cadenasirn.dat\" u 1:2 w l t\"Suceptibles\", \"cadenasirn.dat\" u 1:4 w l t\"Recuperados\"'|gnuplot -persist");

//z vs x
//system("echo ' set title \" I vs t\"; plot \"cadenasirn.dat\" u 1:3 w l t\"Infectados\"'|gnuplot -persist");
/*
//z vs y
system("echo ' set title \" R vs t\"; plot \"ploting.dat\" u 1:4 w l '|gnuplot -persist");

// z vs x ,y

system("echo ' set title \" N vs t\"; plot \"ploting.dat\" u 1:5 w l '|gnuplot -persist");
*/

	//system("echo ' set title \"SIR EDO con Dinamica Vital en rk4\"; plot \"ploting.dat\" u 1:3 w l t\"infec\", \"ploting.dat\" u 1:2 w l t\"sucep\", \"ploting.dat\" u 1:4 w l t\"recov\", \"ploting.dat\" u 1:5 w l t\"pop\"'|gnuplot -persist");

//printf("aqui\n");
exit(0);

}
void cadena_s(double H, double N, double dv[], double V[],int k,double tasa,double dt)
{
	int i=1;
	dv[1]=V[1]+dt*( tasa*k*N - H -tasa*k*V[1]);
	i++;
	while (i<=k)
	{
		dv[i]=V[i]+dt*( tasa*k*V[i-1] - tasa*k*V[i]);
		i++;
	}
	
}
void cadena_i(double H, double dv[], double V[],int k,double tasa_mu,double tasa_gama,double dt)
{
	int i=1;
	dv[1]=V[1]+ dt*(H - (tasa_gama*k + tasa_mu)*V[1]);
	i++;
	while (i<=k)
	{
		dv[i]=V[i]+ dt*(k*tasa_gama*V[i-1] - (tasa_mu + tasa_gama*k)*V[i]);
		i++;
	}
}
