#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "aleatorios.h"
//#include "/Users/javo/libreria/NRUTIL.h"
//#include "/Users/javo/libreria/NRUTIL.c"
//#include "/Users/javo/libreria/SpecialFunctions.h"
//#include "/Users/javo/libreria/NR.h"
#include "estimation.c"
//non linear model darft!!
//void mrqmin(float x[], float y[], float sig[], int ndata, float a[], int ia[], int ma, float **covar, float **alpha, float *chisq,void (*funcs)(float, float [], float *, float [], int), float *alamda);
//void covsrt(float **covar, int ma, int ia[], int mfit);
//void gaussj(float **a, int n, float **b, int m);
//void mrqcof(float x[], float y[], float sig[], int ndata, float a[], int ia[], int ma, float **alpha, float beta[], float *chisq, void (*funcs)(float, float [], float *, float [], int));
/*
b1 = \beta tasa de transmision
mu1 = \mu tasa de mortalidad
g = \gamma tasa de remocion
N1 = poblacion
*/

int main()
{
long int seed;
int N1,s0,s1,i1,r1,f1,aux11,aux12,inc,inc1,inc2, N1_eq;
float t,dt,tasa1,alfa;
FILE *plot1,*plot2,*plot3;

float b1,mu1,g,p;
/* uso las condiciones del Keeling */
/*
N1=100000;
s1=100;
i1=25;
r1=N1-s1-i1;
mu1=1./3640;
b1=27040;
g=1;
dt=0.1;
t=0.;
*/
alfa = 0.05; //valor que va de 0.1 a 0.9 condiciones iniciales
N1=2000000;
N1_eq = N1;
s1=alfa*N1;
s0=s1;
i1=1600;//2500;//10;//0.025*N1;
r1=N1-s1-i1;
mu1=1./80.;//1./70.;//1./(52.*60.);
//b1=520;//4.4;//10.97;//*N1*i1/s1;
g=24.33;//52;//1;
b1 = 15.*(mu1 +g);
dt=0.001;
t=0.;

fprintf(stderr,"seed=? \n");
scanf("%lu",&seed);	
seed=-labs(seed);
plot1=fopen("poisir2.txt","w");
plot2=fopen("poisirw2.txt","w");
plot3=fopen("final2.txt","w");
float count = 0.;
p=0;
inc1=i1;
inc2=0;
fprintf(plot2,"%f\t%d\n",0.,10);
while(t	< 75)
{
	/* *****s1 y s2***** */
	//tasa1=(b1/N1)*s1*i1*dt*cos(2*3.14*t/52)*cos(2*3.14*t/52)*cos(2*3.14*t/52)*cos(2*3.14*t/52);//(0.5 + 0.5*cos(2*3.14*t/52));//incidencia
	//tasa1=(b1/N1)*s1*i1*dt*(1+sin(2.*3.1415*t/52.));
	//tasa2=(b2/N2)*s2*i2*dt;//incidencia2
	tasa1 = (b1/N1)*s1*i1*dt;
	f1=poidev(tasa1,&seed);
	//f2=poidev(tasa2,&seed);
	tasa1=mu1*N1_eq*dt;//nacimientos1
	//tasa2=mu2*N2*dt;//nacimientos2
	aux11=poidev(tasa1,&seed);
	//aux12=poidev(tasa2,&seed);
	tasa1=mu1*s1*dt;//muertes1
	//tasa2=mu*s2*dt;//muertes2
	aux12=poidev(tasa1,&seed);
	//aux22=poidev(tasa2,&seed);
	/*Ecuacion para s(1,2)(t+dt)*/
	s1 = s1 - f1 + aux11 - aux12;
	//s1 = s2 - f2 + aux21 - aux22;
	if(s1<0){s1=0;}
	/* *****i1***** */
	tasa1=mu1*i1*dt; //muerte
	aux11=poidev(tasa1,&seed);
	tasa1=g*i1*dt; //recuperacion
	aux12=poidev(tasa1,&seed); 
	/*Ecuacion para i1(t+dt)*/
	// perturbacion
	if (fabs(count-t)<=dt)
	{
		p =0;//1./*+sin(0.73*t)*/; 
		count=count+1.;
		
	}
	else{p=0;}
	
	i1 = i1 + f1 -aux11 -aux12 +p;
	if(i1<0){i1=0;}
	/*incidencia*/
	inc=f1+p;
	/* *****r1***** */
	tasa1 = mu1*r1*dt; //muerte
	aux11 = poidev(tasa1,&seed);
	/*Ecuacion para r1(t+dt)*/
	r1=r1 +aux12 - aux11;
	if(r1<0){r1=0;}
	/* *****N1***** */
	N1 = s1+i1+r1 +p;
	
	/* imprimo los valores */
	fprintf(plot1,"%f\t%d\n",t,i1);
	inc1+=inc;
	if( (fabs((count-1.)-t)<=0.6*dt) )
	{
		//fprintf(plot2,"%f\t%d\n",t,inc1);
		inc2+=inc1;
		fprintf(plot3,"%f\t%f\n",t,(float)(inc2)/(float)N1);
		inc1=0;
		//fprintf(plot1,"%f\t%f\n",t,((float)s0 - (float)s1)/(float)s0 );
		}
	
	
	/* actualizo los valores para la siguiente generacion*/
	
	t=t+dt;
}
fclose(plot1);fclose(plot2);fclose(plot3);
printf("valor de S(0)*N =%.2f\n",alfa);
	/* Ejecuta en R un grafico */
	//system("echo \"source(\"grafico.r\"| r --vanilla");
exit(0);
}

