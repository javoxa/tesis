#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "integradores_volterra.h"
//#include "parameters.h"
/*=====revange======*/
int main(void)
{
	/*declaro un puntero y abro un archivo para hacer el plot*/
	FILE *plot1,*plot2;
	char file1[20],file2[20];
	
	/*declaro las tasas*/
	//double beta,mu,gama;
	double theta_gama,k_gama,theta_mu;
	
	/*declaro las varianzas*/
	//double var_g,var_mu;
	/*declaracion de variables*/
	double t;//,tf=50.,dt=0.01;
	long int count,size =(tf/dt);
	double Suc,Inf,N_tot,suc,inf,n_tot,ssuc,an,an_1,an_2,max,min; //Suc0,Inf0,Rec0,
	double H[size +2];
	/*valores de las tasas medias*/
	/*
	gama=1.;//periodo medio infeccioso [1/T]
	mu=1./10.;//periodo medio de vida 75 years => 1/75 = 0.013
	beta=2.2;//suc
	*/
	/*en base a las tasas, calculo los k y theta para las gamma*/
	/*para el periodo infeccioso gama*/
	double k_mu=kmu;
	k_gama = 1. /*exponencial k_g = 1*/; 
	theta_gama = 1./(k_gama*gama);
	/*================================================================*/
	/*Comenzamos variando k_mu desde 1 a 100 (en forma entera)*/
	/*para k_mu=1 caso exponencial*/
	//k_mu=1;
	theta_mu = 1./(k_mu*mu);

		/*Ahora variamos la fuerza de infeccion beta, que ira desde un
		 * valor inicial beta_i, hasta un valor final beta_f*/
	
			/*Condiciones iniciales*/
	//Suc0=800.;Inf0=20.;Rec0=180.;
	suc=Suc0;inf=Inf0;
	n_tot=Suc0+Inf0+Rec0;
	N_tot=n_tot;
	count=0;t=0.;ssuc=0.;
	sprintf(file1,"max_%f_%f.dat",beta,k_mu);
	sprintf(file2,"min_%f_%f.dat",beta,k_mu);
	plot1=fopen(file1,"w");
	plot2=fopen(file2,"w");
			do
			{
				H[count] = beta*suc*inf/n_tot;
				Suc = N_tot*F(t,0.,k_mu,theta_mu) + Suc0*Fbar(t,0.,k_mu,theta_mu) - solve_Fbar_rk2(H,count,dt,k_mu,theta_mu);
				//printf("beta=%f\n",beta);
				Inf = Inf0*Fbar(t,0.,k_gama,theta_gama)*Fbar(t,0.,k_mu,theta_mu) 
				+ solve_Fbar_Fbar_rk2(H,count,dt,k_gama,theta_gama,k_mu,theta_mu);
				N_tot=n_tot;
				/*Aca es la condicion de maximos y minimos, mejorar por la que realmente es */

					an=Suc;an_1=suc;an_2=ssuc;
				if (count>2)
				{
					if ( (an_1 > an_2) & (an_1 > an) )
					{
						max=an_1;
						fprintf(plot1,"%.2f\t %f\n",t,max);
					}
					if ( (an_1 < an_2) & (an_1 < an) )
					{
						min=an_1;
						fprintf(plot2,"%.2f\t %f\n",t,min);
					}
				}	

				//printf("%f\t %f\n",t,Inf);
				/*actualizo los valores de sirn*/
				inf=Inf;n_tot=N_tot;ssuc=suc;suc=Suc;
				count++;t+=dt;
			}
			while(count<size);


	fclose(plot1);
	fclose(plot2);
	//escalado(100,100,Imp,Imag);
	//wpgmt(100,100,250,1,Imp);
	//system("echo '	load \"grafico.plt\"	'|gnuplot -persist");

	return 0;
}
