
function MyParameterEstimationSIRDengueData2

%**************************************************************************
%**************************************************************************
%**************************************************************************

%** Description of the program **
% This program is an implementation for estimating a set of parameters
% of a "simple" Susceptible-Infectious-Removed (SIR) model
% (described as a system of ODEs) from epidemiological data (incidence)
% via the least squares approach

%** Input variables **
% None

%** Output variables **
%None

%**************************************************************************
%**************************************************************************
%**************************************************************************


%**************************************************************************
%************ Declaration and initialization of parameters ****************
%**************************************************************************

clc       % Clear the display in the command window.
close all % Clear all stored variables from the Workspace.
clear all % Close all figures.

%**************************************************************************
%************************ loading myData.txt ***********************
%**************************************************************************

load incidence.dat;      % read data
t = incidence(:,1);  % days
incidenceData = incidence(:,2);  % observations

%** Independet variables **
% Time in days
tMin = t(1);            % lower bound for the time
tMax = t(end);       % upper bound for the time
n = length(t); % Total number of points in t

% data plots
figure(1)
a = plot(t,incidenceData,'ro');
legend(a,'Incidence data')
xlabel('Time (in days)')
ylabel('Cases')
xlim([tMin tMax])
ylim([0 ceil(max(incidenceData))+10])
title('Number of new infected and infectious cases (or incidence)')

%**************************************************************************
%**************************************************************************
%**************************************************************************

% Auxiliary parameters
MaxNumIter = 30; % Maximum number of iterations
TOL = 10^(-5); % Tolerance you want for your estimation

%** Initial conditions **
N0 = 87414;             % Initial population size
I0 = incidenceData(1);  % Initial number of infected and infectious individuals
R0 = 0;                 % Initial number of individuals in the removal class

%** Model parameters **
beta_bar = 14.25;        % transmission rate
epsilon = 0.9;
omega = 0.26;
omega2 =0.08;
fase = 0.34 ;

q = [beta_bar epsilon omega R0 omega2 fase]'; % Vector of model parameters
p = length(q);     % dimension of vector q

LB = [1 0.01 0.01 0.001 0.001 -3.14];
UB = [20 1.0 0.9  1 0.4 3.14];


% % noise structure
xi = 0; % Absolute noise.
% % xi = 1/2; % Poisson noise.
% % xi = 1; % Relative noise.

%**************************************************************************
%**************************************************************************
%**************************************************************************

%**************************************************************************
%******************** Least Squares Procedure *****************************
%**************************************************************************

modelParameters = [N0,xi,p]';

numIter = 0;  % counter

% q_opt = 5*ones(p,1);
% q = q_opt;
q_opt = q;

w = ones(n,1);

%** Auxiliary vectors **
convergence = [];
costFunc = [];

% options=optimset('Algorithm','trust-region-reflective','tolfun',10^-6,'TolX',10^-6,'MaxFunEvals',1000,'MaxIter',1000); 
% 'active-set', 'interior-point', 'sqp', 'trust-region-reflective'

options=optimset('tolfun',10^-6,'TolX',10^-6,'MaxFunEvals',100,'MaxIter',100);

while(numIter == 0 | ((norm(q - q_opt) >= TOL) & (numIter < MaxNumIter)))  % do / while
    
    q = q_opt;
    
      [q_opt, J_q_opt] = fminsearch(@(q) objectiveFunctional(t,incidenceData,q,modelParameters,w),q); %,options);
   %  [q_opt, J_q_opt] = fminbnd(@(q) objectiveFunctional(t,incidenceData,q,modelParameters,w),q,[ ],[ ],[ ],[ ],LB,UB,[ ],options);
    
    incidenceModel = [ ];
    for i = 1:length(t)
        incidenceModel(i) = predictedIncidence(t(i),incidenceData,q,modelParameters);
    end
    incidenceModel = incidenceModel';
    
    % weight formulation
    w = incidenceModel.^(-2*xi);
    
    numIter = numIter + 1;
    
    convergence = [convergence; norm(q - q_opt)];
    costFunc = [costFunc; J_q_opt];
    
    figure(2)
    subplot(2,1,1)
    b = plot([1:1:numIter],convergence,'o');
    xlabel('Number of iterations')
    xlim([0 numIter]);
    ylabel('Convergence')
    subplot(2,1,2)
    b = plot([1:1:numIter],costFunc,'o');
    xlabel('Number of iterations')
    xlim([0 numIter]);
    ylabel('Cost functional value J_q_op')    

    figure(3)
    a = plot(t,incidenceData,'ro',t,incidenceModel,'bo--');
    legend(a,'Incidence data','Inicidence from model')
    xlabel('Time [in weeks]')
    ylabel('Cases')
    xlim([tMin tMax])
    ylim([0 ceil(max([max(incidenceData),max(incidenceModel)]))+10])
    title('Number of new infected')
    
    %** Residual plots **
    
    % Residual Plots (CV & NCV)
    
    % 1) Constant variance xi = 0
    
    figure(4)
    subplot(1,2,1)
	plot(t,incidenceData-incidenceModel,'o')
    title('Residual over time plot assuming constant variance')
    xlabel('Time (in weeks)')
    ylabel('Residuals')
    xlim([tMin tMax])
    subplot(1,2,2)
    plot(incidenceModel,incidenceData-incidenceModel,'o')
    title('Model vs. Residual assuming constant variance')
    xlabel('Cases')
    xlim([min(incidenceModel) max(incidenceModel)]);
    ylabel('Residuals')
    
end % end while

%**************************************************************************
%**************************************************************************
%**************************************************************************


% %**************************************************************************
% %************************** Confidence Intervals **************************
% %**************************************************************************
% 

R0 = q_opt(4);
q_opt(4) = R0;

incidenceModel = [ ];
for i = 1:length(t)
    incidenceModel(i) = predictedIncidence(t(i),incidenceData,q_opt,modelParameters);
end
incidenceModel = incidenceModel';

% weight
w = incidenceModel.^(-2*xi);

J_q_opt = objectiveFunctional(t,incidenceData,q_opt,modelParameters,w);
variance = J_q_opt/(n-p); % variance for the error

h = 0.0001; %step size for the q_k parameter

incidenceModel_beta_bar = [ ];
for i = 1:length(t)
    incidenceModel_beta_bar(i) = predictedIncidence(t(i),incidenceData,[q_opt(1)+h q_opt(2) q_opt(3) q_opt(4) q_opt(5) q_opt(6)],modelParameters);
end
incidenceModel_beta_bar = incidenceModel_beta_bar';

incidenceModel_epsilon = [ ];
for i = 1:length(t)
    incidenceModel_epsilon(i) = predictedIncidence(t(i),incidenceData,[q_opt(1) q_opt(2)+h q_opt(3) q_opt(4) q_opt(5) q_opt(6)],modelParameters);
end
incidenceModel_epsilon = incidenceModel_epsilon';

incidenceModel_omega = [ ];
for i = 1:length(t)
    incidenceModel_omega(i) = predictedIncidence(t(i),incidenceData,[q_opt(1) q_opt(2) q_opt(3)+h q_opt(4) q_opt(5) q_opt(6)],modelParameters);
end
incidenceModel_omega = incidenceModel_omega';

incidenceModel_R0 = [ ];
for i = 1:length(t)
    incidenceModel_R0(i) = predictedIncidence(t(i),incidenceData,[q_opt(1) q_opt(2) q_opt(3) q_opt(4)+h q_opt(5) q_opt(6)],modelParameters);
end
incidenceModel_R0 = incidenceModel_R0';

incidenceModel_omega2 = [ ];
for i = 1:length(t)
    incidenceModel_omega2(i) = predictedIncidence(t(i),incidenceData,[q_opt(1) q_opt(2) q_opt(3) q_opt(4) q_opt(5)+h q_opt(6)],modelParameters);
end
incidenceModel_omega2 = incidenceModel_omega2';

incidenceModel_fase = [ ];
for i = 1:length(t)
    incidenceModel_fase(i) = predictedIncidence(t(i),incidenceData,[q_opt(1) q_opt(2) q_opt(3) q_opt(4) q_opt(5) q_opt(6)+h],modelParameters);
end
incidenceModel_fase = incidenceModel_fase';

% Sensitivity Matrix
Chi = zeros(n,p);                        % sensitivity matrix (using foward difference formula)
Chi(:,1) = (incidenceModel_beta_bar - incidenceModel)./h;      % num. approx. of partial deriv. of f with respect of beta_1
Chi(:,2) = (incidenceModel_epsilon - incidenceModel)./h;    % num. approx. of partial deriv. of f with respect of k
Chi(:,3) = (incidenceModel_omega - incidenceModel)./h;    % num. approx. of partial deriv. of f with respect of q_star
Chi(:,4) = (incidenceModel_R0 - incidenceModel)./h;    % num. approx. of partial deriv. of f with respect of q_star
Chi(:,5) = (incidenceModel_omega2 - incidenceModel)./h;
Chi(:,6) = (incidenceModel_fase - incidenceModel)./h;
Chi_T_by_Chi = zeros(p,p);

Chi_T_by_Chi = Chi'*Chi; %

% variance-covariance matrix (p by p)
Sigma = zeros(p,p); % initialize
Sigma = inv(Chi_T_by_Chi/variance);

% Standard Error of each parameter of q
SE = zeros(p); % initialize
SE = diag(sqrt(Sigma));

% Confidence interval for q_{k}_init
% alpha = [0.01 0.05 0.10]; % levels of significant
alpha = [0.05]; % levels of significant

% Confidence interval for q_{k}_LS
for i=1:length(alpha)
    [beta_bar_CI epsilon_CI omega_CI R0_CI omega2_CI fase_CI] = confidenceInterval(SE,q_opt,n,p,alpha(i));
end % for i

% %**************************************************************************
% %**************************************************************************
% %**************************************************************************

% % disp('q_opt = '), disp(q_opt)
% disp('===================================================')        
% disp([' Parameter estimates and ',num2str((1-alpha)*100),'% Confidence intervals '])
% disp('===================================================')        

disp(' ')        

disp(['beta_bar = ',num2str(q_opt(1))])
disp(['SE(beta_bar) = ',num2str(SE(1))])
disp([num2str(beta_bar_CI(1)),' < beta_bar < ',num2str(beta_bar_CI(2))])

disp(' ')        

disp(['epsilon = ',num2str(q_opt(2))])
disp(['SE(epsilon) = ',num2str(SE(2))])
disp([num2str(epsilon_CI(1)),' < epsilon < ',num2str(epsilon_CI(2))])

disp(' ')        

disp(['omega = ',num2str(q_opt(3))])
disp(['SE(omega) = ',num2str(SE(3))])
disp([num2str(omega_CI(1)),' < omega < ',num2str(omega_CI(2))])

disp(' ')        

disp(['R0 = ',num2str(q_opt(4))])
disp(['SE(R0) = ',num2str(SE(4))])
disp([num2str(R0_CI(1)),' < R0 < ',num2str(R0_CI(2))])

disp(' ')

disp(['omega2 = ',num2str(q_opt(5))])
disp(['SE(omega2) = ',num2str(SE(5))])
disp([num2str(omega2_CI(1)),' < omega2 < ',num2str(omega2_CI(2))])

disp(' ')
disp(['fase = ',num2str(q_opt(6))])
disp(['SE(fase) = ',num2str(SE(6))])
disp([num2str(fase_CI(1)),' < fase < ',num2str(fase_CI(2))])

disp(' ')

format shortE

% Selection score

nu = SE./q_opt;

alpha_Sel_Score = norm(nu);

% disp(['Selection Score: alpha(theta) = ',num2str(alpha_Sel_Score)])

disp('Selection Score: alpha(theta) = ') 

alpha_Sel_Score

% disp(' ')

% Condition number

% disp(['Condition number: kappa(Sigma) = ',num2str(cond(Sigma))])

disp('Condition number: kappa(Sigma) = ')

cond_Sigma = cond(Sigma)
%norm(E_Confidence-E_Prediction)
% format shortE
% % Selection score
% nu = SE./q_opt; % vector of coefficients of variation (CV)
% alpha_Sel_Score = norm(nu);
% disp(['Selection Score: ',num2str(alpha_Sel_Score)])
% 
% disp(' ')
% 
% % Condition number
% disp(['Condition number of the variance-covariance matrix: ',num2str(cond(Sigma))])
% 
% disp(' ')        
% 

% ************** confidence and prediction band ***************************

E_Confidence = zeros(n,1);

E_Prediction = zeros(n,1);

 % alpha = [0.01 0.05 0.10]; % levels of significant

alpha = [0.05]; % levels of significant

for i=1:n

    c = Chi(i,:)*Sigma*Chi(i,:)';

    t_star = abs(tinv(alpha/2,n-p)); % statistic of the student-t dist with degree of freedom n-p.

    E_Confidence(i) = sqrt(c)*sqrt(variance)*t_star;

    E_Prediction(i) = sqrt(c+1)*sqrt(variance)*t_star;

end


figure(3)
hold on
a = plot(t,incidenceModel-E_Prediction,'go--',t,incidenceModel+E_Prediction,'go--');
legend(a,'95% prediction band')
xlabel('Time [in weeks]')
ylabel('Cases')
xlim([tMin tMax])
% ylim([0 ceil(max([max(incidenceData),max(incidenceModel)]))+10])
title('Number of new infected')

figure(5)
a = plot(t,incidenceData,'ro',t,incidenceModel,'bo--');
hold on
a = plot(t,incidenceModel-E_Confidence,'go--',t,incidenceModel+E_Confidence,'go--');
legend(a,'95% confidence band')
xlabel('Time [in weeks]')
ylabel('Cases')
xlim([tMin tMax])
% ylim([0 ceil(max([max(incidenceData),max(incidenceModel)]))+10])
title('Number of new infected')

 



%**************************************************************************
%*************** end function MyParameterEstimationMTBI ********************
%**************************************************************************

function [A, SE_A, A_CI, lambda, SE_lambda, lambda_CI, E_Confidence, E_Prediction] = fitcurvedemo3(xdata,ydata,A0,B0)

 

TOL = 10^(-3);

 

MaxNumIter = 25;

% Call fminsearch with a random starting point.

A=A0;

B=B0;

 

q = [A B];

q_opt = q;

 

numIter = 0;

 

while(numIter == 0 | ((norm(q - q_opt) >= TOL) & (numIter < MaxNumIter)))  % do / while

    q = q_opt;

    

    [q_opt, J_q_opt] = fminsearch(@(q) sum((ydata - q(1)*exp(q(2)*xdata)).^2), q);

    

    numIter = numIter+1

end

 

A = q_opt(1);

lambda = q_opt(2);

 

% figure(11)

% plot(xdata,ydata,'.',xdata,A*exp(q_opt*xdata))

 

 

n = length(xdata);

p = length(q_opt);

variance = J_q_opt/(n-p); % variance for error

 

% % Sensitivity Matrix

Chi = zeros(n,p);

Chi = [exp(q_opt(2)*xdata) q_opt(1)*xdata.*exp(q_opt(2)*xdata)];

 

% % covariance matrix (p by p)

Sigma = zeros(p,p); % initialize

Sigma = inv( Chi_T_by_Chi/variance );

 

% % Standard Error of each parameter of q

SE = zeros(p); % initialize

SE = sqrt(diag(Sigma));

 

SE_A = SE(1);

SE_lambda = SE(2);

 

alpha = 0.05; % for 95% CI

% alpha = 0.01; % for 99% CI

t_star = abs(tinv(alpha/2,n-p)); % statistic of the student-t dist with degree of freedom n-p.

 

E_A  = t_star*SE_A;   % margin of error of q_{1} = A

A_CI = [A-E_A A+E_A];  % CI for q_{1} = A

 

E_lambda  = t_star*SE_lambda;   % margin of error of q_{2} = lambda

lambda_CI = [lambda-E_lambda lambda+E_lambda];  % CI for q_{2} = lambda

 

disp([num2str(A_CI(1)),' < A < ',num2str(A_CI(2))])

disp([num2str(lambda_CI(1)),' < lambda < ',num2str(lambda_CI(2))])

 

% ************** confidence and prediction band ***************************

 

E_Confidence = zeros(n,1);

E_Prediction = zeros(n,1);

 

% alpha = [0.01 0.05 0.10]; % levels of significant

alpha = [0.05]; % levels of significant

 

for i=1:n

 

    c = Chi(i,:)*Sigma*Chi(i,:)';

    

    t_star = abs(tinv(alpha/2,n-p)); % statistic of the student-t dist with degree of freedom n-p.

    

    E_Confidence(i) = sqrt(c)*sqrt(variance)*t_star;

    E_Prediction(i) = sqrt(c+1)*sqrt(variance)*t_star;

    

end

 
%%%%%



 

% E_Confidence

% E_Prediction

 

% ************** confidence and prediction band ***************************

 
%**************************************************************************
%************************** List of functions *****************************
%**************************************************************************













