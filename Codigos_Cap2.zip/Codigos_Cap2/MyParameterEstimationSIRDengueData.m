
function MyParameterEstimationSIRDengueData

%**************************************************************************
%**************************************************************************
%**************************************************************************

%** Description of the program **
% This program is an implementation for estimating a set of parameters
% of a "simple" Susceptible-Infectious-Removed (SIR) model
% (described as a system of ODEs) from epidemiological data (incidence)
% via the least squares approach

%** Input variables **
% None

%** Output variables **
%None

%**************************************************************************
%**************************************************************************
%**************************************************************************


%**************************************************************************
%************ Declaration and initialization of parameters ****************
%**************************************************************************

clc       % Clear the display in the command window.
close all % Clear all stored variables from the Workspace.
clear all % Close all figures.

%**************************************************************************
%************************ loading myData.txt ***********************
%**************************************************************************

load incidence.dat;      % read data
t = incidence(:,1);  % days
incidenceData = incidence(:,2);  % observations

%** Independet variables **
% Time in days
tMin = t(1);            % lower bound for the time
tMax = t(end);       % upper bound for the time
n = length(t); % Total number of points in t

% data plots
figure(1)
a = plot(t,incidenceData,'ro');
legend(a,'Incidence data')
xlabel('Time (in week)')
ylabel('Cases')
xlim([tMin tMax])
ylim([0 ceil(max(incidenceData))+10])
title('Number of new infected and infectious cases (or incidence)')

%**************************************************************************
%**************************************************************************
%**************************************************************************

% Auxiliary parameters
MaxNumIter = 10; % Maximum number of iterations
TOL = 10^(-5); % Tolerance you want for your estimation

%** Initial conditions **
N0 = 87414;             % Initial population size
I0 = incidenceData(1);  % Initial number of infected and infectious individuals
R0 = 0;                 % Initial number of individuals in the removal class

%** Model parameters **
beta_bar = 14.25;        % transmission rate
epsilon = 0.9;
omega = 0.26;
omega2 =0.08;
fase = 0.34 ;

q = [beta_bar epsilon omega R0 omega2 fase]'; % Vector of model parameters
p = length(q);     % dimension of vector q

LB = [1 0.1 0.001 0.001 0.001 -3.14];
UB = [20 1.0 0.8  1 0.5 3.14];



% % noise structure
xi = 0; % Absolute noise.
% % xi = 1/2; % Poisson noise.
% % xi = 1; % Relative noise.

%**************************************************************************
%**************************************************************************
%**************************************************************************

%**************************************************************************
%******************** Least Squares Procedure *****************************
%**************************************************************************

modelParameters = [N0,xi,p]';

numIter = 0;  % counter

% q_opt = 5*ones(p,1);
% q = q_opt;
q_opt = q;

w = ones(n,1);

%** Auxiliary vectors **
convergence = [];
costFunc = [];

% options=optimset('Algorithm','trust-region-reflective','tolfun',10^-6,'TolX',10^-6,'MaxFunEvals',1000,'MaxIter',1000); 
% 'active-set', 'interior-point', 'sqp', 'trust-region-reflective'

options=optimset('tolfun',10^-6,'TolX',10^-6,'MaxFunEvals',100,'MaxIter',100);

while(numIter == 0 | ((norm(q - q_opt) >= TOL) & (numIter < MaxNumIter)))  % do / while
    
    q = q_opt;
    
      [q_opt, J_q_opt] = fminsearch(@(q) objectiveFunctional(t,incidenceData,q,modelParameters,w),q); %,options);
  %   [q_opt, J_q_opt] = fmincon(@(q) objectiveFunctional(t,incidenceData,q,modelParameters,w),q,[ ],[ ],[ ],[ ],LB,UB,[ ],options);
    
    incidenceModel = [ ];
    for i = 1:length(t)
        incidenceModel(i) = predictedIncidence(t(i),incidenceData,q,modelParameters);
    end
    incidenceModel = incidenceModel';
    
    % weight formulation
    w = incidenceModel.^(-2*xi);
    
    numIter = numIter + 1;
    
    convergence = [convergence; norm(q - q_opt)];
    costFunc = [costFunc; J_q_opt];
    
    figure(2)
    subplot(2,1,1)
    b = plot([1:1:numIter],convergence,'o');
    xlabel('Number of iterations')
    xlim([0 numIter]);
    ylabel('Convergence')
    subplot(2,1,2)
    b = plot([1:1:numIter],costFunc,'o');
    xlabel('Number of iterations')
    xlim([0 numIter]);
    ylabel('Cost functional value J_q_op')    

    figure(3)
    a = plot(t,incidenceData,'ro',t,incidenceModel,'bo--');
    legend(a,'Incidence data','Inicidence from model')
    xlabel('Time (in days)')
    ylabel('Cases')
    xlim([tMin tMax])
    ylim([0 ceil(max([max(incidenceData),max(incidenceModel)]))+10])
    title('Number of new infected and infectious cases (or incidence)')
    
    %** Residual plots **
    
    % Residual Plots (CV & NCV)
    
    % 1) Constant variance xi = 0
    
    figure(4)
    subplot(1,2,1)
	plot(t,incidenceData-incidenceModel,'o')
    title('Residual over time plot assuming constant variance')
    xlabel('Time (in days)')
    ylabel('Residuals')
    xlim([tMin tMax])
    subplot(1,2,2)
    plot(incidenceModel,incidenceData-incidenceModel,'o')
    title('Model vs. Residual assuming constant variance')
    xlabel('Cases')
    xlim([min(incidenceModel) max(incidenceModel)]);
    ylabel('Residuals')
    
end % end while

%**************************************************************************
%**************************************************************************
%**************************************************************************


% %**************************************************************************
% %************************** Confidence Intervals **************************
% %**************************************************************************
% 
% IC = [S0 I0 R0 C0 zeros(1,(numberOfStatesVariables)*p)];  % Vector of initial conditions
% 
% %** ODE solver **
% [t,y] = ode45(@odeModelSensitivity,t,IC,[ ],[q_opt;modelParameters]);
% %** Output **
% C = y(:,4); % Cumulative incidence
% incidenceModel = incidence(t,C);
% 
% % weight
% w = incidenceModel.^(-2*xi);
% 
% J_q_opt = objectiveFunctional(t,incidenceData,IC,q_opt,modelParameters,w);
% variance = J_q_opt/(n-p); % variance for the error
% 
% % Sensitivity Matrix
% Chi = zeros(n,p);
% 
% x = numberOfStatesVariables;
% Chi(1,:) = [y(1,x+p*((numberOfStatesVariables)-1)+1) y(1,x+p*((numberOfStatesVariables)-1)+2)]; % w(N,1)(t1) w(N,2)(t1)
% for i=2:n
%     Chi(i,:) = [y(i,x+p*((numberOfStatesVariables)-1)+1)-y(i-1,x+p*((numberOfStatesVariables)-1)+1) y(i,x+p*((numberOfStatesVariables)-1)+2)-y(i-1,x+p*((numberOfStatesVariables)-1)+2)]; % w(N,1)(ti)-w(N,1)(ti-1) w(N,2)(ti)-w(N,2)(ti-1)
% end
% 
% Chi_T_by_Chi = zeros(p,p);
% 
% Chi_T_by_Chi = Chi'*Chi; %
% 
% % variance-covariance matrix (p by p)
% Sigma = zeros(p,p); % initialize
% Sigma = inv(Chi_T_by_Chi/variance);
% 
% % Standard Error of each parameter of q
% SE = zeros(p); % initialize
% SE = diag(sqrt(Sigma));
% 
% % Confidence interval for q_{k}_init
% % alpha = [0.01 0.05 0.10]; % levels of significant
% alpha = [0.05]; % levels of significant
% 
% % Confidence interval for q_{k}_LS
% for i=1:length(alpha)
%     [beta_CI, gamma_CI] = confidenceInterval(SE,q_opt,n,p,alpha(i));
% end % for i
% 
% %**************************************************************************
% %**************************************************************************
% %**************************************************************************

% % disp('q_opt = '), disp(q_opt)
% disp('===================================================')        
% disp([' Parameter estimates and ',num2str((1-alpha)*100),'% Confidence intervals '])
% disp('===================================================')        

disp(' ')        

disp(['beta_bar = ',num2str(q_opt(1))])
% disp([num2str(beta_CI(1)),' < beta < ',num2str(beta_CI(2))])

disp(' ')        

disp(['epsilon = ',num2str(q_opt(2))])
% disp([num2str(gamma_CI(1)),' < gamma < ',num2str(gamma_CI(2))])

disp(' ')        

disp(['omega = ',num2str(q_opt(3))])
% disp([num2str(beta_CI(1)),' < beta < ',num2str(beta_CI(2))])

disp(' ')        

disp(['R0 = ',num2str(q_opt(4))])
% disp([num2str(gamma_CI(1)),' < gamma < ',num2str(gamma_CI(2))])

disp(' ')

disp(['omega2 = ',num2str(q_opt(5))])
%disp([num2str(omega2_CI(1)),' < omega2 < ',num2str(omega2_CI(2))])

disp(' ')
disp(['fase = ',num2str(q_opt(6))])
%disp([num2str(fase_CI(1)),' < fase < ',num2str(fase_CI(2))])

disp(' ')

% format shortE
% % Selection score
% nu = SE./q_opt; % vector of coefficients of variation (CV)
% alpha_Sel_Score = norm(nu);
% disp(['Selection Score: ',num2str(alpha_Sel_Score)])
% 
% disp(' ')
% 
% % Condition number
% disp(['Condition number of the variance-covariance matrix: ',num2str(cond(Sigma))])
% 
% disp(' ')        
% 
%**************************************************************************
%*************** end function MyParameterEstimationSIR ********************
%**************************************************************************


%**************************************************************************
%************************** List of functions *****************************
%**************************************************************************













