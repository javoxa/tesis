
%**************************************************************************
%*********************** Objective Functional *****************************
%**************************************************************************
function output = objectiveFunctional(t,incidenceData,q,modelParameters,w)

%R0 = q(4);
%R0 = R0*(R0>0);
%q(4) = R0;

incidenceModel = [ ];
for i = 1:length(t)
    incidenceModel(i) = predictedIncidence(t(i),incidenceData,q,modelParameters);
end
incidenceModel = incidenceModel';

% weights formulation
xi = modelParameters(2);

w = incidenceModel.^(-2*xi);

output = norm( sqrt(w).*(incidenceData - incidenceModel) )^2;
%**************************************************************************
%**************************************************************************
%**************************************************************************
