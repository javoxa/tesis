

%**************************************************************************
%**************************** incidence model *****************************
%**************************************************************************
function prediction = predictedIncidence(t,incidenceData,q,modelParameters)

beta_bar = q(1);
epsilon = q(2);
omega = q(3);
R0 = q(4);
omega2 = q(5);
fase = q (6);
N = modelParameters(1);

if((t/floor(t)) == 1)
prediction = beta_bar.*(1 + epsilon.*sin(omega*t)).*sin(omega2.*t).*sin(omega2.*t + fase)*exp(-R0.*t)+ 0.5 ;%0.5*(1+sin(3.14.*R0.*t));% + sin(3.14.*R0.*t);%.*sin(3.14.*R0.*t); %*exp(-R0.*t).+sin(0.5*3.14.*t);% sin(3.14.*R0.*t);

    else    
prediction = beta_bar.*(1 + epsilon.*sin(omega*t)).*sin(R0.*t).*sin(R0.*t).*exp(-R0.*t) ;
end


%**************************************************************************
%**************************************************************************
%**************************************************************************
