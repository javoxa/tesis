
%**************************************************************************
%**************** Confidence Interval for q_{k} ***************************
%**************************************************************************
function [beta_bar_CI, epsilon_CI, omega_CI, R0_CI, omega2_CI, fase_CI] = confidenceInterval(SE,q,n,p,alpha)
% SE - Standard Error of q_{k}
% q - vector of parameters
% n - total number of data points
% p - number of parameters in q
% alpha - level of significance

t_star = abs(tinv(alpha/2,n-p)); % statistic of the student-t dist with degree of freedom n-p.

E_beta_bar = t_star*SE(1);   % margin of error of q_{1} = beta0
E_epsilon = t_star*SE(2);   % margin of error of q_{1} = beta0
E_omega = t_star*SE(3);   % margin of error of q_{1} = beta0
E_R0 = t_star*SE(4);   % margin of error of q_{2} = gamma
E_omega2 = t_star*SE(5);
E_fase = t_star*SE(6);

beta_bar_CI = [q(1)-E_beta_bar q(1)+E_beta_bar];  % CI for q_{1} = beta0
epsilon_CI = [q(2)-E_epsilon q(2)+E_epsilon];  % CI for q_{1} = beta0
omega_CI = [q(3)-E_omega q(3)+E_omega];  % CI for q_{1} = beta0
R0_CI = [q(4)-E_R0 q(4)+E_R0];  % CI for q_{2} = gamma
omega2_CI = [q(5)-E_omega2 q(5)+E_omega2];
fase_CI = [q(6)-E_fase q(6)+E_fase];
%**************************************************************************
%**************************************************************************
%**************************************************************************
