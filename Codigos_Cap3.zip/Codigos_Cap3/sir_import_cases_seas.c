#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "aleatorios.h"
//#include "/Users/javo/libreria/NRUTIL.h"
//#include "/Users/javo/libreria/NRUTIL.c"
//#include "/Users/javo/libreria/SpecialFunctions.h"
//#include "/Users/javo/libreria/NR.h"
#include "estimation.c"
//Para el caso de escalon usar los valos bi y bd borde izquierdo =0, borde derecho = 3 y
//Para el caso sinuoidal usar tasa1 = (1/N1)*s1*i1*dt* (1 + cos(t*2*3.14/52)) * (4.4); // 4.4 es beta_0

int main()
{
long int seed;
int N1,s0,s1,i1,r1,f1,aux11,aux12,inc,inc1,inc2, N1_eq ,contador,sg,anio;
float t,dt,tasa1,alfa;
FILE *plot1,*plot2,*plot3;
float seas,bi,bd; // seas:ancho de estacionalidad
//bi : borde izquierdo (cuando empieza seas)
//bd : borde derecho (cuando termina seas)

float b1,mu1,g,p;

alfa = 0.80; //valor que va de 0.1 a 0.9 da la condicion inicial
N1=90000;
N1_eq = N1;
s1=alfa*N1;
s0=s1;
sg=s0;
i1=10;//2500;//10;//0.025*N1;
r1=N1-s1-i1;
mu1=1./(52.*60.);//1./70.;//1./(52.*60.);
b1=4.4;//10.97;//*N1*i1/s1;
g=1.;//24.33;//52;//1;
//b1 = 15.*(mu1 +g);
dt=0.001;
t=0.;

fprintf(stderr,"seed=? \n");
scanf("%lu",&seed);	
seed=-labs(seed);
plot1=fopen("poisir2.txt","w");
plot2=fopen("poisirw2.txt","w");
plot3=fopen("final2.txt","w");
float count = 0.;
p=0;
inc1=i1;
inc2=0;
anio=1;
contador = 1;
fprintf(plot1,"%f\t%f\n",0.,alfa);
fprintf(plot2,"%f\t%d\n",0.,10);
fprintf(plot3,"%f\t%f\n",0.,10./(float)N1_eq);
bi=0;
bd=12;
seas = bd - bi;
while(t	< 520)
{
	t = contador*dt;
	
	if ((count-t)<=0.6*dt)
	{
		if ( bi <= t ){b1 = 4.4;}
		else {b1=0.;}
		
	}
	if ( bd <= t ){bd=bd+52;bi=bi+52; printf("bi = %f\t bd=%f\n",bi,bd);b1=0.;}
	

	tasa1 = (b1/N1)*s1*i1*dt;
	f1=poidev(tasa1,&seed); // transmision
	
	tasa1=mu1*N1_eq*dt;//nacimientos
	
	aux11=poidev(tasa1,&seed);

	tasa1=mu1*s1*dt;//muertes de S
	
	aux12=poidev(tasa1,&seed);
	
	/*Ecuacion para s1(t+dt)*/
	s1 = s1 - f1 + aux11 - aux12;
	s0+= aux11 - aux12 -f1; //s0 siempre tiene los susceptibles al tiempo anterior
	if(s1<0){s1=0;}
	/* *****i1***** */
	tasa1=mu1*i1*dt; //muerte de I
	aux11=poidev(tasa1,&seed);
	tasa1=g*i1*dt; //recuperacion
	aux12=poidev(tasa1,&seed); 
	/*Ecuacion para i1(t+dt)*/
	// perturbacion
	if ((count-t)<=0.6*dt)
	{
		p =0;//1./*+sin(0.73*t)*/;
		//printf("semana = %f\t tasa=%f\n",t,b1);
		//printf("%f\n",t);
		//count=count+1.;
		printf("semana = %f\t tasa=%f\n",t,b1);
		count++;
		if ( (int)count%52==0 )//( (anio<= count) | (count <= anio) )
		{
			p=10.;
			//p = round(10*ran2(&seed));
			anio+=1;
			//printf("semana = %f\t anio=%d\n",t,anio);
		}
		
	}
	else{p=0;}
	
	i1 = i1 + f1 -aux11 -aux12 +p;
	if(i1<0){i1=0;}
	/*incidencia*/
	inc=f1+p;
	/* *****r1***** */
	tasa1 = mu1*r1*dt; //muerte de R
	aux11 = poidev(tasa1,&seed);
	/*Ecuacion para r1(t+dt)*/
	r1=r1 +aux12 - aux11;
	if(r1<0){r1=0;}
	/* *****N1***** */
	N1 = s1+i1+r1 +p;  //balance
	
	/* imprimo los valores */
	//fprintf(plot1,"%f\t%d\n",t,i1);
	inc1+=inc;
	
	if( ( fabs( (count-1.)-t)<=0.06*dt) )
	//if (  (count)== t+1 )
	{
		
		fprintf(plot2,"%f\t%d\n",t,inc1); //incidencia semanal
		inc2+=inc1;
		fprintf(plot1,"%f\t%f\n",t,(float)(s0)/(float)N1); //acumulada con s0 sg=s0;
		
		fprintf(plot3,"%f\t%f\n",t,(float)(inc2)/(float)N1_eq);//acumuladas
		inc1=0;
		s0=s1;
		
	}
	
	
	/* actualizo los valores para la siguiente generacion*/
	
	//t=t+dt;
	contador++;
}
fclose(plot1);fclose(plot2);fclose(plot3);
printf("valor de S(0)*N =%.2f\n",alfa);
printf("valor de N_final =%d\n",N1);
printf("valor de S_final =%d\n",s1);
printf("valor de S_final / N_final  =%f\n",(float)s1/(float)N1);
	/* Ejecuta en R un grafico */
	//system("echo \"source(\"grafico.r\"| r --vanilla");
exit(0);
}
//install.packages('/home/gjavier/nloptr', dependencies = FALSE, 
//--configure-args = c('--with-nlopt-cflags=-I/home/gjavier/include',' --with-nlopt-libs=-L/home/gjavier/lib' ))





//R CMD INSTALL --configure-vars='LIBS=-L/home/gjavier/lib CPPFLAGS=-I/home/gjavier/include' nloptr_1.0.4.tar

//_1.0.4.tar




//R CMD INSTALL --configure-vars='LIBS=-L/home/gjavier/lib CPPFLAGS=-I/home/gjavier/include' nloptr_1.0.4.tar 












