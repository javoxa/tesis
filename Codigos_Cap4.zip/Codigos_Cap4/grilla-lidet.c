#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "aleatorios.h"
//#include "libmul.h"

//#define N 2 //Lado de la grilla cuadrada

void reparto(int);

int n1,n2,n3,n4;
long int seed;

int main()
{


int i,j,N,d;
char exitx[20];
float D;

fprintf(stderr,"seed=? \n");
scanf("%lu",&seed);	
seed=-fabs(seed);

for(d=1;d<=9;d++)
{

D=d/10.;
printf("dif %d %f\n",d,D);
FILE *plot2;
sprintf(exitx, "liaD0.2%d.dat", d);
plot2=fopen(exitx,"w");




for(N=2;N<=100;N++)
{
//printf("lado N %d\n",N);
int x[N+2][N+2], x_total, x_2,x_4,xaux;
int t=0,t0=100,T=1000;
int n, m_izq[N+2][N+2], m_der[N+2][N+2], m_up[N+2][N+2], m_down[N+2][N+2];

float P,M,PP,MM;
float tasa;
double lnf=0.;
float r=3.6,K=250.;
char salida[20];

//FILE *plot1;

//sprintf(salida, "grilla%d.dat", N);
//plot1=fopen(salida,"w");





xaux=0;
		

//inicializacion
 
 for(i=1;i<=N;i++)
 {
 for(j=1;j<=N;j++)x[i][j]=K*ran1(&seed);
	//printf("%d\n",x[1][1]);
 }

// comienza el ciclo temporal
P=M=PP=MM=0;
while(t	< T+t0)
{
    
	for(i=1;i<=N;i++)
	{
		for(j=1;j<=N;j++){
		x[i][j]=r*x[i][j]*(1.-x[i][j]/K);// reclutamiento
		m_izq[i][j]=0.25*D*x[i][j];
		m_der[i][j]=0.25*D*x[i][j];
		m_up[i][j]=0.25*D*x[i][j];
		m_down[i][j]=0.25*D*x[i][j];
		}
	}
	
	//periodic boundary conditions

	for(j=0;j<=N+1;j++){m_down[0][j]=m_down[N][j];  m_up[N+1][j]= m_up[1][j];} 	
	for(i=0;i<=N+1;i++){ m_der[i][0]= m_der[i][N]; m_izq[i][N+1]=m_izq[i][1];}


	// dispersion
	x_total=x_2=x_4=0;
	for(i=1;i<=N;i++)
	{	
		for(j=1;j<=N;j++){
		x[i][j]=x[i][j]-(m_izq[i][j]+m_der[i][j]+m_up[i][j]+m_down[i][j])+m_der[i][j-1]+m_izq[i][j+1]+m_down[i-1][j]+m_up[i+1][j];
		if(x[i][j]<0)x[i][j]=0;
	    x_total+=x[i][j];
		if(i<=2 && j<=2)x_2+=x[i][j];
		if(i<=4 && j<=4)x_4+=x[i][j];
		}
	}
	if(x_total!=xaux) lnf+=log(fabs(x_total-xaux));
		
//if(t>t0)fprintf(plot1,"%d %d %f\n",t-t0,x_total,lnf);
	xaux=x_total;  
t++;
}//while
fprintf(plot2,"%d %f\n",N,lnf/(T+t0));
//fclose(plot1);
//exit(0);
}
fclose(plot2);
}
}

