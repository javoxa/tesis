#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "/Users/javo/libreria/aleatorios.h"
#include "/Users/javo/libreria/SpecialFunctions.h"
#define MAXX 8
#define MAXY 8
#define dt 0.1

//meta guacha
float seas(int ii, int jj, float tt, float bbeta, float oomega,long int MM[MAXX][MAXY]);
void periodica(int nnx, int nny,long int IN[MAXX][MAXY], long int OUT[MAXX][MAXY]);
void matrixf5(int nx, int ny,long int IN[MAXX][MAXY],long int OUT[MAXX][MAXY]);
int main()
{
	long int i,j,f1,n1,n2,nx,ny,incidencia=0,aux2,count=52,k;
	float aux,inf,tasa,omega;
	double t=0.,tf=520.;
	float beta,gama,mu;
	long int Sa[MAXX][MAXY],S[MAXX][MAXY],Ia[MAXX][MAXY],I[MAXX][MAXY],Ra[MAXX][MAXY],R[MAXX][MAXY],Na[MAXX][MAXY];
	long int seed;
	double entero = round(t);
	//initial conditions
	//rates
	//dt=0.10;
	beta = 4.4;
	mu = 1/(60 * 52);
	gama = 1.;
	//seassonality
	omega = 2*3.14/52.;
	// distribution of populations
	nx=MAXX - 2;
	ny=MAXY - 2;
	for (i=1;i<=nx;i++)
	{
		for (j=1;j<=ny;j++)
		{
			Na[i][j] = 100;
			Sa[i][j] = Na[i][j]*0.6;
			Ia[i][j] = 6;
			Ra[i][j] = Na[i][j] - Sa[i][j] - Ia[i][j];
			incidencia = incidencia + Ia[i][j];
		}
	}
	periodica(nx,ny,Na,Na); //periodic N
	periodica(nx,ny,Sa,Sa); //periodic S
	periodica(nx,ny,Ia,Ia); //periodic I
	periodica(nx,ny,Ra,Ra); //periodic R
	printf("%g\t%lu\t%lu\n",t,incidencia,Ia[3][3]);
	incidencia = 0;
	
	fprintf(stderr,"seed=? \n");
	scanf("%lu",&seed);	
	seed=-labs(seed);
	tf=tf/dt;
	aux2=0;
	for (k=1;k<=tf;k++) 
	{
		t=k*dt;
		
		for (i=1;i<=nx;i++)
		{
			for (j=1;j<=ny;j++)
			{
				
				//infectados parche ij y sus vecinos cercanos
				inf = Ia[i][j]+Ia[i-1][j]+Ia[i+1][j]+Ia[i][j-1]+Ia[i][j+1];
				aux = seas(i,j,t,beta,omega,Na);
				tasa = aux*Sa[i][j]*inf*dt;
				f1 = poidev(tasa,&seed);
				if (f1<0){f1=0;}
				tasa = mu*Na[i][j]*dt;
				n1 = poidev(tasa,&seed);
				tasa = mu*Sa[i][j]*dt;
				n2 = poidev(tasa,&seed);
				S[i][j]=Sa[i][j] +n1 -f1 -n2;
				if (S[i][j] < 0 ){S[i][j] = 0;}
				//infected
				tasa = gama*Ia[i][j]*dt;
				n1 = poidev(tasa,&seed);
				tasa = mu*Ia[i][j]*dt;
				n2 = poidev(tasa,&seed);
				I[i][j] = Ia[i][j] + f1 -n1 -n2;
				if (I[i][j] < 0 ){I[i][j] = 0;}
				//perturbation in I(t)
				if ((int)t%2 == 0) {I[nx][ny]=I[nx][ny] +2;I[3][3]=I[3][3]+2;}
				//recovery
				tasa = mu*Ra[i][j]*dt;
				n2 = poidev(tasa,&seed);
				R[i][j] = Ra[i][j] + n1 -n2;
				if (R[i][j] < 0){R[i][j] = 0;}
				//population
				Na[i][j] = S[i][j] + I[i][j] + R[i][j];
				//incidence
				incidencia = incidencia + f1;
				if ((i==3) & (j==3)){aux2 = aux2 + f1;}
			
			}
		}
		
		//printf("%g\t%lu\t%lu\n",t,incidencia,I[nx][ny]);
		//incidencia =0;
		//aux2= fabs(t-count);
		
		//para imprimir
		if (fabs(t - round(t))<=t*1E-6)
		{
			printf("%g\t%lu\t%lu\n",t,incidencia,aux2);
			incidencia = 0;
			aux2=0;
			
			
			/*if (fabs(t - round(t))<=count*1E-4)
			{
				Ia[nx][ny]= Ia[nx][ny]+3;
				count+=52;
				//printf("%g\t%lu\t%lu\n",t,incidencia,aux2);
			}*/
			
		}
		//perturbacion
		
		//actualizo datos
		matrixf5(nx,ny,S,Sa);
		matrixf5(nx,ny,I,Ia);
		matrixf5(nx,ny,R,Ra);
		
		//condiciones periodicas
		periodica(nx,ny,Na,Na); //periodic N
		periodica(nx,ny,Sa,Sa); //periodic S
		periodica(nx,ny,Ia,Ia); //periodic I
		periodica(nx,ny,Ra,Ra); //periodic R
		//imprimir
		
		/*
		if (fabs(count-t)<=dt)
		{
			printf(".0%f\t%d\n",t,incidencia);
			count=count +1.;
			incidencia = 0;
		}*/
	}

	exit(0);
}
float seas(int ii, int jj, float tt, float bbeta, float oomega, long int MM[MAXX][MAXY])
{
	//modelling to seasonalinity
	float salida;
	int M;
	
	M = MM[ii][jj]+MM[ii-1][jj]+MM[ii+1][jj]+MM[ii][jj-1]+MM[ii][jj+1];
	
	salida = (bbeta/M)*0.5*(1. + sin(oomega*tt));
	if (salida > 0) {return salida;}
	else {return 0.;}
	
}
void periodica(int nnx, int nny,long int IN[MAXX][MAXY], long int OUT[MAXX][MAXY])
{
	int ii,jj;
	for (ii=1;ii<=nnx;ii++)
	{
		for (jj=1;jj<=nny;jj++)
		{
			
			OUT[0][jj]= IN[nnx][jj];
			OUT[nnx+1][jj]= IN[1][jj];
			OUT[ii][0]= IN[ii][nny];
			OUT[ii][nny+1]= IN[ii][1];
		}
	}
	//return (0);
}
void matrixf5(int nx, int ny, long int IN[MAXX][MAXY], long int OUT[MAXX][MAXY])
{
	int ii,jj;
	for (ii=1;ii<=nx;ii++)
	{
		for (jj=1;jj<=ny;jj++)
		{
			OUT[ii][jj]= IN[ii][jj];

		}
	}
	//return 0;
	
}














