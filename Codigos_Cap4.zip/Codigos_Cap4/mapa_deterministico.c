#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "aleatorios.h"

#define N 10 //Lado de la grilla cuadrada

void snapshot2D(int [][N+2],int);

long int seed;

int main()
{
int i,j;
int x[N+2][N+2], x_total;
int t=0,t0=0,T=1001;
int n, m_izq[N+2][N+2], m_der[N+2][N+2], m_up[N+2][N+2], m_down[N+2][N+2];
char salida[20];
float r=3.8,K=250.,D=0.45;
FILE *plot1;
sprintf(salida, "grilladet0%2.0f.dat", 100*D);
plot1=fopen(salida,"w");

fprintf(stderr,"seed=? \n");
scanf("%lu",&seed);	
seed=-fabs(seed);

xaux=0;

//inicializacion

 
 for(i=1;i<=N;i++)
 {
 for(j=1;j<=N;j++)x[i][j]=K*ran1(&seed);
 }

// comienza el ciclo temporal
while(t	< T+t0)
{
    
	for(i=1;i<=N;i++)
	{
		for(j=1;j<=N;j++){
		x[i][j]=r*x[i][j]*(1.-x[i][j]/K);// reclutamiento
		m_izq[i][j]=0.25*D*x[i][j];
		m_der[i][j]=0.25*D*x[i][j];
		m_up[i][j]=0.25*D*x[i][j];
		m_down[i][j]=0.25*D*x[i][j];
		}
	}
	
	//periodic boundary conditions

	for(j=0;j<=N+1;j++){m_down[0][j]=m_down[N][j];  m_up[N+1][j]= m_up[1][j];} 	
	for(i=0;i<=N+1;i++){ m_der[i][0]= m_der[i][N]; m_izq[i][N+1]=m_izq[i][1];}


	// dispersion
	x_total=0;
	for(i=1;i<=N;i++)
	{	
		for(j=1;j<=N;j++){
		x[i][j]=x[i][j]-(m_izq[i][j]+m_der[i][j]+m_up[i][j]+m_down[i][j])+m_der[i][j-1]+m_izq[i][j+1]+m_down[i-1][j]+m_up[i+1][j];
		if(x[i][j]<0)x[i][j]=0;
	    x_total+=x[i][j];
		}
	}
	if(x_total!=xaux) lnf+=log(fabs(x_total-xaux));
	xaux=x_total; 

		
if(t>t0)
	fprintf(plot1,"%d %f\n",N,lnf/(T+t0));
	t++;
}//while
fclose(plot1);

snapshot2D(x,1);

exit(0);
}


//////
void snapshot2D(int xx[][N+2], int foto_number)
{
FILE *picture;
int i,j;
char string[20];

sprintf(string, "foto2D%d.dat", foto_number);

picture=fopen(string,"w");

	for(i=1;i<=N;i++){
		for(j=1;j<=N;j++){fprintf(picture,"%d ",xx[i][j]);}
		fprintf(picture,"\n");
	}
fclose(picture);	
}

