#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "/Users/javo/libreria/aleatorios.h"
#include "/Users/javo/libreria/SpecialFunctions.h"
#define MAXX 32
#define MAXY 32
#define dt 0.1

//meta guacha
float seas(int ii, int jj, float tt, float bbeta, float oomega,long int MM[MAXX][MAXY],int vecx, int vecy);
void periodica(int nnx, int nny,long int IN[MAXX][MAXY], long int OUT[MAXX][MAXY]);
void matrixf5(int nx, int ny,long int IN[MAXX][MAXY],long int OUT[MAXX][MAXY]);

int main()
{
	long int i,j,f1,n1,n2,nx,ny,incidencia=0,aux2,count=52,k,indice1,indice2;
	float aux,inf,tasa,omega,a,Nf,Sf,Reff,frac,r1,r2;
	
	frac = 0.8;
	
	double t=0.,tf=520.;
	float beta,gama,mu;
	long int Sa[MAXX][MAXY],S[MAXX][MAXY],Ia[MAXX][MAXY],I[MAXX][MAXY],Ra[MAXX][MAXY],R[MAXX][MAXY],Na[MAXX][MAXY],Ref[MAXX][MAXY];
	FILE *plot;
	long int seed;
	float bi,bd,b1; //para la estacionalidad escalon
	bd = 3.; //ancho
	bi =0.;
	b1=1.; 
	plot=fopen("plotmeta.dat","w");
	fprintf(stderr,"seed=? \n");
	scanf("%lu",&seed);	
	seed=-labs(seed);
	//initial conditions
	//rates
	//dt=0.10;
	beta = 6.4;
	mu = 1/(60 * 52);
	gama = 1;
	//seassonality
	omega = 2*3.14/52.;
	// distribution of populations
	nx=MAXX - 2;
	ny=MAXY - 2;
	
	//primero hago todo cero
	for (i=1;i<=nx;i++)
	{
		for (j=1;j<=ny;j++)
		{
			Na[i][j] = 0;
			Sa[i][j] = 0;
			Ia[i][j] = 0;
			Ra[i][j] = 0;
			Ref[i][j] = 0;
		}
	}
	//primero se introduce los casos al azar
	{
					//tengo que mejorar esta perturbacion con un ciclo for o while
					//1
					a=ran2(&seed);
					indice1=a*nx; if (indice1 <=1){indice1=1;}
					a=ran2(&seed); indice2=a*ny; if (indice2 <=1){indice2=1;}
					Ia[indice1][indice2]=Ia[indice1][indice2]+1;
					if ((indice1==3) & (indice2==2)){aux2 = aux2 + 1;}
					//2
					a=ran2(&seed);
					indice1=a*nx; if (indice1 <=1){indice1=1;}
					a=ran2(&seed); indice2=a*ny; if (indice2 <=1){indice2=1;}
					Ia[indice1][indice2]=Ia[indice1][indice2]+1; 
					if ((indice1==3) & (indice2==2)){aux2 = aux2 + 1;}
					//3
					a=ran2(&seed);
					indice1=a*nx; if (indice1 <=1){indice1=1;}
					a=ran2(&seed); indice2=a*ny; if (indice2 <=1){indice2=1;}
					Ia[indice1][indice2]=Ia[indice1][indice2]+1; 
					if ((indice1==3) & (indice2==2)){aux2 = aux2 + 1;}
					
					
					
					//printf("%g\t%lu\t[%lu][%lu]\t%lu\n",t,I[indice1][indice2],indice1,indice2,aux2);
	}
	
	//ahora hago la introduccion de las demas condiciones
	
	for (i=1;i<=nx;i++)
	{
		for (j=1;j<=ny;j++)
		{
			a=ran2(&seed); // distribucion variable para la poblacion
			Na[i][j] = 100*a*2.;
			Sa[i][j] = Na[i][j]*frac;
			//Ia[i][j] = 0;
			Ra[i][j] = Na[i][j] - Sa[i][j] - Ia[i][j];
			if (Ra[i][j]<0){Ra[i][j] = 0;Ia[i][j] = 0;}
			incidencia = incidencia + Ia[i][j];
			Ref[i][j] = 0.;
		}
	}
	//condiciones periodicas
	periodica(nx,ny,Na,Na); //periodic N
	periodica(nx,ny,Sa,Sa); //periodic S
	periodica(nx,ny,Ia,Ia); //periodic I
	periodica(nx,ny,Ra,Ra); //periodic R
	periodica(nx,ny,Ref,Ref); //periodic Ref
	//printf("%g\t%lu\t%lu\n",t,incidencia,Ia[3][3]);
	incidencia = 0;
	
	// calculo r efectivo promedio con los 4 vecinos
	// sumo los Nf y Sf a la vez
	
	Nf=0.;Sf=0.;Reff=0.;
	for (i=1;i<=nx;i++)
	{
		for (j=1;j<=ny;j++)
		{
			
			Nf = Nf + Na[i][j];
			Sf = Sf + Sa[i][j];
			r1 = (float)Sa[i][j]+(float)Sa[i-1][j]+(float)Sa[i+1][j]+(float)Sa[i][j-1]+(float)Sa[i][j+1];
			r2 = (float)Na[i][j]+(float)Na[i-1][j]+(float)Na[i+1][j]+(float)Na[i][j-1]+(float)Na[i][j+1];
			Ref[i][j] = b1*beta*(r1/r2);
			Reff = Reff + b1*beta*(r1/r2);
		}
	}
	r1 = (float)nx*(float)ny;
	printf("N0 = %.0f \t S0 = %.0f \t Ref = %f \t <Reff> = %f\n",Nf,Sf,b1*beta*Sf/Nf,Reff/r1 );

	
	fprintf(plot,"%f\t%f\t%lu\t%f\t%f\n",t,10.,Ia[3][3],Sf/Nf,Reff/(float)(nx*ny));

	tf=tf/dt;
	aux2=0;
	for (k=1;k<=tf;k++) 
	{
		t=k*dt;
		//comentar o hacer el bd mas grande que tf
		if (fabs(t - round(t))<=t*1E-6)
		{
			if ( bi <= t ){b1 = 1;}
			else {b1=0.;}
		}
		if ( bd <= t ){bd=bd+52;bi=bi+52; /* printf("bi = %f\t bd=%f\n",bi,bd);*/b1=0.;}
		
		for (i=1;i<=nx;i++)
		{
			for (j=1;j<=ny;j++)
			{
				
				//suceptibles
				 //conexion azar
					a=ran2(&seed);
					indice1=a*nx;
					if (indice1 <=1){indice1=1;}
					a=ran2(&seed);
					indice2=a*ny;
					if (indice2 <=1){indice2=1;}
				// infectados con vecinos y uno al azar	
				inf = Ia[i][j]+Ia[i-1][j]+Ia[i+1][j]+Ia[i][j-1]+Ia[i][j+1]+Ia[indice1][indice2];
				aux = b1*seas(i,j,t,beta,omega,Na,indice1,indice2);
				tasa = aux*Sa[i][j]*inf*dt;
				f1 = poidev(tasa,&seed);
				if (f1<0){f1=0;}
				tasa = 1.*mu*Na[i][j]*dt;
				n1 = poidev(tasa,&seed);
				tasa = mu*Sa[i][j]*dt;
				n2 = poidev(tasa,&seed);
				S[i][j]=Sa[i][j] +n1 -f1 -n2;
				if (S[i][j] < 0 ){S[i][j] = 0;}
				//infected
				tasa = gama*Ia[i][j]*dt;
				n1 = poidev(tasa,&seed);
				tasa = mu*Ia[i][j]*dt;
				n2 = poidev(tasa,&seed);
				I[i][j] = Ia[i][j] + f1 -n1 -n2;
				if (I[i][j] < 0 ){I[i][j] = 0;}
				
				//recovery
				tasa = mu*Ra[i][j]*dt;
				n2 = poidev(tasa,&seed);
				R[i][j] = Ra[i][j] + n1 -n2;
				if (R[i][j] < 0){R[i][j] = 0;}
				//population
				Na[i][j] = S[i][j] + I[i][j] + R[i][j];
				//incidence
				incidencia = incidencia + f1;
				if ((i==3) & (j==2)){aux2 = aux2 + f1;}
			
			}
		}
		//if (6<=aux2 ){printf("%g\t%lu\t%lu\n",t,incidencia,aux2);}
		//perturbation in I(t)
		if ( ((long int)k == 10) || ((long int)k == 20) || ((long int)k == 30) )
				{
					//tengo que mejorar esta perturbacion con un ciclo for o while
					a=ran2(&seed);
					indice1=a*nx;
					if (indice1 <=1){indice1=1;}
					a=ran2(&seed);
					indice2=a*ny;
					if (indice2 <=1){indice2=1;}
					I[indice1][indice2]=I[indice1][indice2]+1; //1
					if ((indice1==3) & (indice2==2)){aux2 = aux2 + 1;}
					a=ran2(&seed);
					indice1=a*nx;
					if (indice1 <=1){indice1=1;}
					a=ran2(&seed);
					indice2=a*ny;
					if (indice2 <=1){indice2=1;}
					I[indice1][indice2]=I[indice1][indice2]+1; //2
					if ((indice1==3) & (indice2==2)){aux2 = aux2 + 1;}
					a=ran2(&seed);
					indice1=a*nx;
					if (indice1 <=1){indice1=1;}
					a=ran2(&seed);
					indice2=a*ny;
					if (indice2 <=1){indice2=1;}
					I[indice1][indice2]=I[indice1][indice2]+1; //3
					if ((indice1==3) & (indice2==2)){aux2 = aux2 + 1;}
					//printf("%g\t%lu\t[%lu][%lu]\t%lu\n",t,I[indice1][indice2],indice1,indice2,aux2);
				}
				if ( ((long int)k%520 == 0) || ((long int)k%521 == 0) || ((long int)k%522 == 0) )
				{
					//tengo que mejorar esta perturbacion con un ciclo for o while
					a=ran2(&seed);
					indice1=a*nx;
					if (indice1 <=1){indice1=1;}
					a=ran2(&seed);
					indice2=a*ny;
					if (indice2 <=1){indice2=1;}
					I[indice1][indice2]=I[indice1][indice2]+1; //1
					if ((indice1==3) & (indice2==2)){aux2 = aux2 + 1;}
					a=ran2(&seed);
					indice1=a*nx;
					if (indice1 <=1){indice1=1;}
					a=ran2(&seed);
					indice2=a*ny;
					if (indice2 <=1){indice2=1;}
					I[indice1][indice2]=I[indice1][indice2]+1; //2
					if ((indice1==3) & (indice2==2)){aux2 = aux2 + 1;}
					a=ran2(&seed);
					indice1=a*nx;
					if (indice1 <=1){indice1=1;}
					a=ran2(&seed);
					indice2=a*ny;
					if (indice2 <=1){indice2=1;}
					I[indice1][indice2]=I[indice1][indice2]+1; //3
					if ((indice1==3) & (indice2==2)){aux2 = aux2 + 1;}
					//printf("%g\t%lu\t[%lu][%lu]\t%lu\n",t,I[indice1][indice2],indice1,indice2,aux2);
				}
				

		//para imprimir a t entero
		if (fabs(t - round(t))<=t*1E-6)
		{
			Nf=0;Sf=0;Reff=0;
			for (i=1;i<=nx;i++)
			{
				for (j=1;j<=ny;j++)
				{
					Nf = Nf + Na[i][j];
					Sf = Sf + Sa[i][j];
					r1 = (float)Sa[i][j]+(float)Sa[i-1][j]+(float)Sa[i+1][j]+(float)Sa[i][j-1]+(float)Sa[i][j+1];
					r2 = (float)Na[i][j]+(float)Na[i-1][j]+(float)Na[i+1][j]+(float)Na[i][j-1]+(float)Na[i][j+1];
					Ref[i][j] = b1*beta*(r1/r2);
					Reff = Reff + b1*beta*(r1/r2);
				}
			}
			r1 = (float)nx*(float)ny;
			//imprimir el Reff
			if (1.<=t){fprintf(plot,"%g\t%lu\t%lu\t%f\t%f\n",t,incidencia,aux2,beta*b1*Sf/Nf,Reff/r1);}
			//printf("%f\n",t);
			//printf("TT=%f\n",TT);
			//printf(" Sf/Nf = %f\n",Sf/Nf );
			incidencia = 0;
			aux2=0;
			
		}

		
		//actualizo datos
		matrixf5(nx,ny,S,Sa);
		matrixf5(nx,ny,I,Ia);
		matrixf5(nx,ny,R,Ra);
		
		//condiciones periodicas
		periodica(nx,ny,Na,Na); //periodic N
		periodica(nx,ny,Sa,Sa); //periodic S
		periodica(nx,ny,Ia,Ia); //periodic I
		periodica(nx,ny,Ra,Ra); //periodic R
		//imprimir
		

	}
	fclose(plot);
	Nf=0;Sf=0;Reff=0;
	for (i=1;i<=nx;i++)
	{
		for (j=1;j<=ny;j++)
		{
			
			Nf = Nf + Na[i][j];
			Sf = Sf + Sa[i][j];
			r1 = (float)Sa[i][j]+(float)Sa[i-1][j]+(float)Sa[i+1][j]+(float)Sa[i][j-1]+(float)Sa[i][j+1];
			r2 = (float)Na[i][j]+(float)Na[i-1][j]+(float)Na[i+1][j]+(float)Na[i][j-1]+(float)Na[i][j+1];
			Ref[i][j] = b1*beta*(r1/r2);
			Reff = Reff + b1*beta*(r1/r2);

		}
	}
	r1 = (float)nx*(float)ny;
	printf("Nf = %.0f \t Sf = %.0f \t Ref = %f \t <Reff> = %f\n",Nf,Sf,b1*beta*(float)Sf/(float)Nf,Reff/r1 );

	exit(0);
}
float seas(int ii, int jj, float tt, float bbeta, float oomega, long int MM[MAXX][MAXY],int vecx, int vecy)
{
	//modelling to seasonalinity
	float salida;
	int M;
	//poblacion con vecinos y uno al azar
	M = MM[ii][jj]+MM[ii-1][jj]+MM[ii+1][jj]+MM[ii][jj-1]+MM[ii][jj+1] + MM[vecx][vecy];
	
	//salida = (bbeta/M)*(1 + sin(oomega*tt));
	salida = (bbeta/M);
	if (salida > 0) {return salida;}
	else {return 0.;}
	
}

void periodica(int nnx, int nny,long int IN[MAXX][MAXY], long int OUT[MAXX][MAXY])
{
	int ii,jj;
	for (ii=1;ii<=nnx;ii++)
	{
		for (jj=1;jj<=nny;jj++)
		{
			
			OUT[0][jj]= IN[nnx][jj];
			OUT[nnx+1][jj]= IN[1][jj];
			OUT[ii][0]= IN[ii][nny];
			OUT[ii][nny+1]= IN[ii][1];
		}
	}
	//return (0);
}
void matrixf5(int nx, int ny, long int IN[MAXX][MAXY], long int OUT[MAXX][MAXY])
{
	int ii,jj;
	for (ii=1;ii<=nx;ii++)
	{
		for (jj=1;jj<=ny;jj++)
		{
			OUT[ii][jj]= IN[ii][jj];

		}
	}
	//return 0;
	
}














